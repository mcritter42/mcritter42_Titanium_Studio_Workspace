var args = arguments[0] || {};

$.image.image = model.attributes.urls.preview;

$.titleLabel.text = args.title || "";

$.row_id = model.id || "";