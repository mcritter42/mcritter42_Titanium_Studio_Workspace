function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId40(e) {
        if (e && e.fromAdapter) return;
        var opts = __alloyId40.opts || {};
        var models = doFilter(__alloyId39);
        var len = models.length;
        var __alloyId35 = [];
        for (var i = 0; len > i; i++) {
            var __alloyId36 = models[i];
            __alloyId36.__transform = doTransform(__alloyId36);
            var __alloyId38 = {
                template: "undefined" != typeof __alloyId36.__transform["template"] ? __alloyId36.__transform["template"] : __alloyId36.get("template"),
                userName: {
                    text: "undefined" != typeof __alloyId36.__transform["title"] ? __alloyId36.__transform["title"] : __alloyId36.get("title")
                },
                userAvatar: {
                    image: "undefined" != typeof __alloyId36.__transform["image"] ? __alloyId36.__transform["image"] : __alloyId36.get("image")
                },
                properties: {
                    modelId: "undefined" != typeof __alloyId36.__transform["modelId"] ? __alloyId36.__transform["modelId"] : __alloyId36.get("modelId")
                }
            };
            __alloyId35.push(__alloyId38);
        }
        opts.animation ? $.__views.section.setItems(__alloyId35, opts.animation) : $.__views.section.setItems(__alloyId35);
    }
    function androidBackEventHandler(_event) {
        _event.cancelBubble = true;
        _event.bubbles = false;
        Ti.API.debug("androidback event");
        $.friendsWindow.removeEventListener("androidback", androidBackEventHandler);
        $.friendsWindow.close();
    }
    function filterClicked(_event) {
        var itemSelected;
        itemSelected = _event.index;
        $.section.deleteItemsAt(0, $.section.items.length);
        switch (itemSelected) {
          case 0:
            getAllUsersExceptFriends();
            break;

          case 1:
            loadFriends();
        }
    }
    function followBtnClicked(_event) {
        Alloy.Globals.PW.showIndicator("Updating User");
        var currentUser = Alloy.Globals.currentUser;
        var selUser = getModelFromSelectedRow(_event);
        currentUser.followUser(selUser.model.id, function(_resp) {
            _resp.success ? updateFollowersFriendsLists(function() {
                getAllUsersExceptFriends(function() {
                    Alloy.Globals.PW.hideIndicator();
                });
            }) : alert("Error trying to follow " + selUser.displayName);
            Alloy.Globals.PW.hideIndicator();
        });
        _event.cancelBubble = true;
    }
    function getModelFromSelectedRow(_event) {
        var item = _event.section.items[_event.itemIndex];
        var selectedUserId = item.properties.modelId;
        return {
            model: $.friendUserCollection.get(selectedUserId),
            displayName: item.userName.text
        };
    }
    function followingBtnClicked(_event) {
        Alloy.Globals.PW.showIndicator("Updating User");
        var currentUser = Alloy.Globals.currentUser;
        var selUser = getModelFromSelectedRow(_event);
        currentUser.unFollowUser(selUser.model.id, function(_resp) {
            _resp.success ? updateFollowersFriendsLists(function() {
                Alloy.Globals.PW.hideIndicator();
                e;
                loadFriends(function() {
                    Alloy.Globals.PW.hideIndicator();
                    alert("You are no longer following " + selUser.displayName);
                });
            }) : alert("Error unfollowing " + selUser.displayName);
        });
        _event.cancelBubble = true;
    }
    function initialize() {
        $.filter.index = 0;
        Alloy.Globals.PW.showIndicator("Loading...");
        updateFollowersFriendsLists(function() {
            Alloy.Globals.PW.hideIndicator();
            $.collectionType = "fullItem";
            getAllUsersExceptFriends();
        });
    }
    function updateFollowersFriendsLists(_callback) {
        var currentUser = Alloy.Globals.currentUser;
        currentUser.getFollowers(function(_resp) {
            if (_resp.success) {
                $.followersIdList = _.pluck(_resp.collection.models, "id");
                currentUser.getFriends(function(_resp) {
                    _resp.success ? $.friendsIdList = _.pluck(_resp.collection.models, "id") : alert("Error updating friends and followers");
                    _callback();
                });
            } else {
                alert("Error updating friends and followers");
                _callback();
            }
        });
    }
    function loadFriends(_callback) {
        var user = Alloy.Globals.currentUser;
        Alloy.Globals.PW.showIndicator("Loading Friends...");
        user.getFriends(function(_resp) {
            if (_resp.success) if (0 === _resp.collection.models.length) $.friendUserCollection.reset(); else {
                $.collectionType = "friends";
                $.friendUserCollection.reset(_resp.collection.models);
                $.friendUserCollection.trigger("sync");
            } else alert("Error loading followers");
            Alloy.Globals.PW.hideIndicator();
            _callback && _callback();
        });
    }
    function getAllUsersExceptFriends(_callback) {
        var where_params = null;
        $.collectionType = "fullItem";
        Alloy.Globals.PW.showIndicator("Loading Users...");
        $.friendUserCollection.reset();
        if ($.friendsIdList.length) var where_params = {
            _id: {
                $nin: $.friendsIdList
            }
        };
        $.friendUserCollection.fetch({
            data: {
                per_page: 100,
                order: "-last_name",
                where: where_params && JSON.stringify(where_params)
            },
            success: function() {
                Alloy.Globals.PW.hideIndicator();
                _callback && _callback();
            },
            error: function() {
                Alloy.Globals.PW.hideIndicator();
                alert("Error Loading Users");
                _callback && _callback();
            }
        });
    }
    function doTransform(model) {
        var displayName, image, user = model.toJSON();
        image = user.photo && user.photo.urls ? user.photo.urls.square_75 || user.photo.urls.thumb_100 || user.photo.urls.original || "missing.gif" : "missing.gif";
        displayName = user.first_name || user.last_name ? (user.first_name || "") + " " + (user.last_name || "") : user.email;
        var modelParams = {
            title: displayName,
            image: image,
            modelId: user.id,
            template: $.collectionType
        };
        return modelParams;
    }
    function doFilter(_collection) {
        return _collection.filter(function(_i) {
            var attrs = _i.attributes;
            return _i.id !== Alloy.Globals.currentUser.id && ("false" === attrs.admin || !attrs.admin);
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "friends";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.friendUserCollection = Alloy.createCollection("user");
    $.__views.friendsWindow = Ti.UI.createWindow({
        backgroundColor: "#fff",
        title: "Friends",
        id: "friendsWindow"
    });
    $.__views.filterContainer = Ti.UI.createView({
        id: "filterContainer"
    });
    $.__views.friendsWindow.add($.__views.filterContainer);
    var __alloyId11 = [];
    var __alloyId14 = {
        title: "\n							Users\n						"
    };
    __alloyId11.push(__alloyId14);
    var __alloyId15 = {
        title: "\n							Friends\n						"
    };
    __alloyId11.push(__alloyId15);
    $.__views.filter = Ti.UI.iOS.createTabbedBar({
        labels: __alloyId11,
        id: "filter"
    });
    $.__views.filterContainer.add($.__views.filter);
    var __alloyId16 = {};
    var __alloyId19 = [];
    var __alloyId20 = {
        type: "Ti.UI.View",
        childTemplates: function() {
            var __alloyId21 = [];
            var __alloyId22 = {
                type: "Ti.UI.ImageView",
                bindId: "userAvatar",
                properties: {
                    bindId: "userAvatar"
                }
            };
            __alloyId21.push(__alloyId22);
            var __alloyId23 = {
                type: "Ti.UI.Label",
                bindId: "userName",
                properties: {
                    width: Ti.UI.SIZE,
                    height: Ti.UI.SIZE,
                    color: "#000",
                    font: {
                        fontSize: "18sp"
                    },
                    textAlign: "center",
                    bindId: "userName"
                }
            };
            __alloyId21.push(__alloyId23);
            return __alloyId21;
        }(),
        properties: {}
    };
    __alloyId19.push(__alloyId20);
    var __alloyId25 = {
        type: "Ti.UI.Button",
        properties: {
            title: "Follow"
        },
        events: {
            click: followBtnClicked
        }
    };
    __alloyId19.push(__alloyId25);
    var __alloyId18 = {
        properties: {
            name: "fullItem",
            height: "40dp",
            width: Ti.UI.FILL
        },
        childTemplates: __alloyId19
    };
    __alloyId16["fullItem"] = __alloyId18;
    var __alloyId28 = [];
    var __alloyId29 = {
        type: "Ti.UI.View",
        childTemplates: function() {
            var __alloyId30 = [];
            var __alloyId31 = {
                type: "Ti.UI.ImageView",
                bindId: "userAvatar",
                properties: {
                    bindId: "userAvatar"
                }
            };
            __alloyId30.push(__alloyId31);
            var __alloyId32 = {
                type: "Ti.UI.Label",
                bindId: "userName",
                properties: {
                    width: Ti.UI.SIZE,
                    height: Ti.UI.SIZE,
                    color: "#000",
                    font: {
                        fontSize: "18sp"
                    },
                    textAlign: "center",
                    bindId: "userName"
                }
            };
            __alloyId30.push(__alloyId32);
            return __alloyId30;
        }(),
        properties: {}
    };
    __alloyId28.push(__alloyId29);
    var __alloyId34 = {
        type: "Ti.UI.Button",
        properties: {
            title: "UnFollow"
        },
        events: {
            click: followingBtnClicked
        }
    };
    __alloyId28.push(__alloyId34);
    var __alloyId27 = {
        properties: {
            name: "friends",
            height: "40dp",
            width: Ti.UI.FILL
        },
        childTemplates: __alloyId28
    };
    __alloyId16["friends"] = __alloyId27;
    $.__views.section = Ti.UI.createListSection({
        id: "section"
    });
    var __alloyId39 = Alloy.Collections["$.friendUserCollection"] || $.friendUserCollection;
    __alloyId39.on("fetch destroy change add remove reset", __alloyId40);
    var __alloyId41 = [];
    __alloyId41.push($.__views.section);
    $.__views.listView = Ti.UI.createListView({
        sections: __alloyId41,
        templates: __alloyId16,
        id: "listView"
    });
    $.__views.friendsWindow.add($.__views.listView);
    $.__views.friends = Ti.UI.createTab({
        window: $.__views.friendsWindow,
        title: "Friends",
        id: "friends"
    });
    $.__views.friends && $.addTopLevelView($.__views.friends);
    exports.destroy = function() {
        __alloyId39.off("fetch destroy change add remove reset", __alloyId40);
    };
    _.extend($, $.__views);
    arguments[0] || {};
    $.filter.addEventListener("click", filterClicked);
    $.friendsWindow.addEventListener("androidback", androidBackEventHandler);
    $.getView().addEventListener("focus", function() {
        !$.initialized && initialize();
        $.initialized = true;
    });
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;