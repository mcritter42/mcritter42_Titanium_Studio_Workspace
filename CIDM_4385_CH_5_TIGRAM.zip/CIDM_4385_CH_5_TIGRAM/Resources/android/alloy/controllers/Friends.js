function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId34(e) {
        if (e && e.fromAdapter) return;
        var opts = __alloyId34.opts || {};
        var models = doFilter(__alloyId33);
        var len = models.length;
        var __alloyId29 = [];
        for (var i = 0; len > i; i++) {
            var __alloyId30 = models[i];
            __alloyId30.__transform = doTransform(__alloyId30);
            var __alloyId32 = {
                template: "undefined" != typeof __alloyId30.__transform["template"] ? __alloyId30.__transform["template"] : __alloyId30.get("template"),
                userName: {
                    text: "undefined" != typeof __alloyId30.__transform["title"] ? __alloyId30.__transform["title"] : __alloyId30.get("title")
                },
                userAvatar: {
                    image: "undefined" != typeof __alloyId30.__transform["image"] ? __alloyId30.__transform["image"] : __alloyId30.get("image")
                },
                properties: {
                    modelId: "undefined" != typeof __alloyId30.__transform["modelId"] ? __alloyId30.__transform["modelId"] : __alloyId30.get("modelId")
                }
            };
            __alloyId29.push(__alloyId32);
        }
        opts.animation ? $.__views.section.setItems(__alloyId29, opts.animation) : $.__views.section.setItems(__alloyId29);
    }
    function androidBackEventHandler(_event) {
        _event.cancelBubble = true;
        _event.bubbles = false;
        Ti.API.debug("androidback event");
        $.friendsWindow.removeEventListener("androidback", androidBackEventHandler);
        $.friendsWindow.close();
    }
    function filterClicked(_event) {
        var itemSelected;
        itemSelected = _event.rowIndex;
        $.section.deleteItemsAt(0, $.section.items.length);
        switch (itemSelected) {
          case 0:
            getAllUsersExceptFriends();
            break;

          case 1:
            loadFriends();
        }
    }
    function followBtnClicked(_event) {
        Alloy.Globals.PW.showIndicator("Updating User");
        var currentUser = Alloy.Globals.currentUser;
        var selUser = getModelFromSelectedRow(_event);
        currentUser.followUser(selUser.model.id, function(_resp) {
            _resp.success ? updateFollowersFriendsLists(function() {
                getAllUsersExceptFriends(function() {
                    Alloy.Globals.PW.hideIndicator();
                });
            }) : alert("Error trying to follow " + selUser.displayName);
            Alloy.Globals.PW.hideIndicator();
        });
        _event.cancelBubble = true;
    }
    function getModelFromSelectedRow(_event) {
        var item = _event.section.items[_event.itemIndex];
        var selectedUserId = item.properties.modelId;
        return {
            model: $.friendUserCollection.get(selectedUserId),
            displayName: item.userName.text
        };
    }
    function followingBtnClicked(_event) {
        Alloy.Globals.PW.showIndicator("Updating User");
        var currentUser = Alloy.Globals.currentUser;
        var selUser = getModelFromSelectedRow(_event);
        currentUser.unFollowUser(selUser.model.id, function(_resp) {
            _resp.success ? updateFollowersFriendsLists(function() {
                Alloy.Globals.PW.hideIndicator();
                e;
                loadFriends(function() {
                    Alloy.Globals.PW.hideIndicator();
                    alert("You are no longer following " + selUser.displayName);
                });
            }) : alert("Error unfollowing " + selUser.displayName);
        });
        _event.cancelBubble = true;
    }
    function initialize() {
        $.filter.index = 0;
        Alloy.Globals.PW.showIndicator("Loading...");
        updateFollowersFriendsLists(function() {
            Alloy.Globals.PW.hideIndicator();
            $.collectionType = "fullItem";
            getAllUsersExceptFriends();
        });
    }
    function updateFollowersFriendsLists(_callback) {
        var currentUser = Alloy.Globals.currentUser;
        currentUser.getFollowers(function(_resp) {
            if (_resp.success) {
                $.followersIdList = _.pluck(_resp.collection.models, "id");
                currentUser.getFriends(function(_resp) {
                    _resp.success ? $.friendsIdList = _.pluck(_resp.collection.models, "id") : alert("Error updating friends and followers");
                    _callback();
                });
            } else {
                alert("Error updating friends and followers");
                _callback();
            }
        });
    }
    function loadFriends(_callback) {
        var user = Alloy.Globals.currentUser;
        Alloy.Globals.PW.showIndicator("Loading Friends...");
        user.getFriends(function(_resp) {
            if (_resp.success) if (0 === _resp.collection.models.length) $.friendUserCollection.reset(); else {
                $.collectionType = "friends";
                $.friendUserCollection.reset(_resp.collection.models);
                $.friendUserCollection.trigger("sync");
            } else alert("Error loading followers");
            Alloy.Globals.PW.hideIndicator();
            _callback && _callback();
        });
    }
    function getAllUsersExceptFriends(_callback) {
        var where_params = null;
        $.collectionType = "fullItem";
        Alloy.Globals.PW.showIndicator("Loading Users...");
        $.friendUserCollection.reset();
        if ($.friendsIdList.length) var where_params = {
            _id: {
                $nin: $.friendsIdList
            }
        };
        $.friendUserCollection.fetch({
            data: {
                per_page: 100,
                order: "-last_name",
                where: where_params && JSON.stringify(where_params)
            },
            success: function() {
                Alloy.Globals.PW.hideIndicator();
                _callback && _callback();
            },
            error: function() {
                Alloy.Globals.PW.hideIndicator();
                alert("Error Loading Users");
                _callback && _callback();
            }
        });
    }
    function doTransform(model) {
        var displayName, image, user = model.toJSON();
        image = user.photo && user.photo.urls ? user.photo.urls.square_75 || user.photo.urls.thumb_100 || user.photo.urls.original || "missing.gif" : "missing.gif";
        displayName = user.first_name || user.last_name ? (user.first_name || "") + " " + (user.last_name || "") : user.email;
        var modelParams = {
            title: displayName,
            image: image,
            modelId: user.id,
            template: $.collectionType
        };
        return modelParams;
    }
    function doFilter(_collection) {
        return _collection.filter(function(_i) {
            var attrs = _i.attributes;
            return _i.id !== Alloy.Globals.currentUser.id && ("false" === attrs.admin || !attrs.admin);
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "friends";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.friendUserCollection = Alloy.createCollection("user");
    $.__views.friendsWindow = Ti.UI.createWindow({
        backgroundColor: "#fff",
        title: "Friends",
        id: "friendsWindow"
    });
    $.__views.filterContainer = Ti.UI.createView({
        id: "filterContainer"
    });
    $.__views.friendsWindow.add($.__views.filterContainer);
    $.__views.androidPickerContainer = Ti.UI.createView({
        id: "androidPickerContainer"
    });
    $.__views.filterContainer.add($.__views.androidPickerContainer);
    $.__views.filter = Ti.UI.createPicker({
        id: "filter"
    });
    $.__views.androidPickerContainer.add($.__views.filter);
    var __alloyId7 = [];
    $.__views.column1 = Ti.UI.createPickerColumn({
        id: "column1"
    });
    __alloyId7.push($.__views.column1);
    $.__views.__alloyId8 = Ti.UI.createPickerRow({
        title: "Users",
        id: "__alloyId8"
    });
    $.__views.column1.addRow($.__views.__alloyId8);
    $.__views.__alloyId9 = Ti.UI.createPickerRow({
        title: "Friends",
        id: "__alloyId9"
    });
    $.__views.column1.addRow($.__views.__alloyId9);
    $.__views.filter.add(__alloyId7);
    var __alloyId10 = {};
    var __alloyId13 = [];
    var __alloyId14 = {
        type: "Ti.UI.View",
        childTemplates: function() {
            var __alloyId15 = [];
            var __alloyId16 = {
                type: "Ti.UI.ImageView",
                bindId: "userAvatar",
                properties: {
                    bindId: "userAvatar"
                }
            };
            __alloyId15.push(__alloyId16);
            var __alloyId17 = {
                type: "Ti.UI.Label",
                bindId: "userName",
                properties: {
                    width: Ti.UI.SIZE,
                    height: Ti.UI.SIZE,
                    color: "#000",
                    font: {
                        fontSize: "18sp"
                    },
                    textAlign: "center",
                    bindId: "userName"
                }
            };
            __alloyId15.push(__alloyId17);
            return __alloyId15;
        }(),
        properties: {}
    };
    __alloyId13.push(__alloyId14);
    var __alloyId19 = {
        type: "Ti.UI.Button",
        properties: {
            title: "Follow"
        },
        events: {
            click: followBtnClicked
        }
    };
    __alloyId13.push(__alloyId19);
    var __alloyId12 = {
        properties: {
            name: "fullItem",
            height: "40dp",
            width: Ti.UI.FILL
        },
        childTemplates: __alloyId13
    };
    __alloyId10["fullItem"] = __alloyId12;
    var __alloyId22 = [];
    var __alloyId23 = {
        type: "Ti.UI.View",
        childTemplates: function() {
            var __alloyId24 = [];
            var __alloyId25 = {
                type: "Ti.UI.ImageView",
                bindId: "userAvatar",
                properties: {
                    bindId: "userAvatar"
                }
            };
            __alloyId24.push(__alloyId25);
            var __alloyId26 = {
                type: "Ti.UI.Label",
                bindId: "userName",
                properties: {
                    width: Ti.UI.SIZE,
                    height: Ti.UI.SIZE,
                    color: "#000",
                    font: {
                        fontSize: "18sp"
                    },
                    textAlign: "center",
                    bindId: "userName"
                }
            };
            __alloyId24.push(__alloyId26);
            return __alloyId24;
        }(),
        properties: {}
    };
    __alloyId22.push(__alloyId23);
    var __alloyId28 = {
        type: "Ti.UI.Button",
        properties: {
            title: "UnFollow"
        },
        events: {
            click: followingBtnClicked
        }
    };
    __alloyId22.push(__alloyId28);
    var __alloyId21 = {
        properties: {
            name: "friends",
            height: "40dp",
            width: Ti.UI.FILL
        },
        childTemplates: __alloyId22
    };
    __alloyId10["friends"] = __alloyId21;
    $.__views.section = Ti.UI.createListSection({
        id: "section"
    });
    var __alloyId33 = Alloy.Collections["$.friendUserCollection"] || $.friendUserCollection;
    __alloyId33.on("fetch destroy change add remove reset", __alloyId34);
    var __alloyId35 = [];
    __alloyId35.push($.__views.section);
    $.__views.listView = Ti.UI.createListView({
        sections: __alloyId35,
        templates: __alloyId10,
        id: "listView"
    });
    $.__views.friendsWindow.add($.__views.listView);
    $.__views.friends = Ti.UI.createTab({
        window: $.__views.friendsWindow,
        title: "Friends",
        id: "friends"
    });
    $.__views.friends && $.addTopLevelView($.__views.friends);
    exports.destroy = function() {
        __alloyId33.off("fetch destroy change add remove reset", __alloyId34);
    };
    _.extend($, $.__views);
    arguments[0] || {};
    $.filter.addEventListener("change", filterClicked);
    $.friendsWindow.addEventListener("androidback", androidBackEventHandler);
    $.getView().addEventListener("focus", function() {
        !$.initialized && initialize();
        $.initialized = true;
    });
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;