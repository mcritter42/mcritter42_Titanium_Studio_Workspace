function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function handleButtonClicked(_event) {
        var returnParams = {
            success: false,
            content: null
        };
        "saveButton" === _event.source.id && (returnParams = {
            success: true,
            content: $.commentContent.value
        });
        callbackFunction && callbackFunction(returnParams);
    }
    function doOpen() {
        $.getView().activity.onCreateOptionsMenu = function(_event) {
            $.getView().activity;
            var actionBar = $.getView().activity.actionBar;
            if (actionBar) {
                actionBar.displayHomeAsUp = true;
                actionBar.onHomeIconItemSelected = function() {
                    $.getView().close();
                };
            } else alert("No Action Bar Found");
            var mItemSave = _event.menu.add({
                id: "saveButton",
                title: "Save Comment",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                icon: Ti.Android.R.drawable.ic_menu_save
            });
            mItemSave.addEventListener("click", function(_event) {
                _event.source.id = "saveButton";
                handleButtonClicked(_event);
            });
            var mItemCancel = _event.menu.add({
                id: "cancelButton",
                title: "Cancel",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                icon: Ti.Android.R.drawable.ic_menu_close_clear_cancel
            });
            mItemCancel.addEventListener("click", function(_event) {
                _event.source.id = "cancelButton";
                handleButtonClicked(_event);
            });
        };
        setTimeout(function() {
            $.commentContent.focus();
        }, 250);
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "commentInput";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.mainWindow = Ti.UI.createWindow({
        backgroundColor: "#fff",
        id: "mainWindow",
        title: "New Comment"
    });
    $.__views.mainWindow && $.addTopLevelView($.__views.mainWindow);
    doOpen ? $.__views.mainWindow.addEventListener("open", doOpen) : __defers["$.__views.mainWindow!open!doOpen"] = true;
    $.__views.__alloyId2 = Ti.UI.createScrollView({
        height: "240dp",
        id: "__alloyId2"
    });
    $.__views.mainWindow.add($.__views.__alloyId2);
    $.__views.commentContent = Ti.UI.createTextArea({
        borderWidth: 2,
        borderColor: "#bbb",
        borderRadius: 5,
        top: "5dp",
        left: "5dp",
        right: "5dp",
        bottom: "240dp",
        color: "black",
        font: {
            fontSize: "16dp"
        },
        suppressReturn: false,
        autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: true,
        id: "commentContent"
    });
    $.__views.__alloyId2.add($.__views.commentContent);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var parameters = arguments[0] || {};
    parameters.photo || {};
    parameters.parentController || {};
    var callbackFunction = parameters.callback || null;
    false;
    false;
    __defers["$.__views.mainWindow!open!doOpen"] && $.__views.mainWindow.addEventListener("open", doOpen);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;