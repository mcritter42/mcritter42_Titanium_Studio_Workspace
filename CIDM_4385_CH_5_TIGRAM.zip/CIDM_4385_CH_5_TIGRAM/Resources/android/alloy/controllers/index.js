function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doOpen() {
        var activity = $.getView().activity;
        var menuItem = null;
        activity.onCreateOptionsMenu = function(e) {
            Ti.API.info("IN activity.onCreateOptionsMenu");
            Ti.API.info("Active Tab: " + $.tabGroup.activeTab.title);
            if ("Settings" === $.tabGroup.activeTab.title) {
                menuItem = e.menu.add({
                    title: "Logout",
                    showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS
                });
                menuItem.addEventListener("click", function() {
                    $.settingsController.handleLogoutMenuClick();
                });
            } else if ("Feed" === $.tabGroup.activeTab.title) {
                menuItem = e.menu.add({
                    title: "Take Photo",
                    showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                    icon: Ti.Android.R.drawable.ic_menu_camera
                });
                menuItem.addEventListener("click", function() {
                    $.feedController.cameraButtonClicked();
                });
            }
        };
        activity.invalidateOptionsMenu();
        $.tabGroup.addEventListener("blur", function() {
            $.getView().activity.invalidateOptionsMenu();
        });
    }
    function initializePushNotifications(_user) {
        Alloy.Globals.pushToken = null;
        var pushLib = require("pushNotifications");
        pushLib.initialize(_user, function(_pushData) {
            Ti.API.info("I GOT A PUSH NOTIFICATION");
            var payload;
            try {
                payload = _pushData.payload ? JSON.parse(_pushData.payload) : _pushData;
            } catch (e) {
                payload = {};
            }
            Ti.UI.createAlertDialog({
                title: payload.android.title || "Alert",
                message: payload.android.alert || "",
                buttonNames: [ "Ok" ]
            }).show();
        }, function(_pushInitData) {
            if (_pushInitData.success) {
                Alloy.Globals.pushToken = _pushInitData.data.deviceToken;
                Ti.API.debug("Success: Initializing Push Notifications " + JSON.stringify(_pushInitData));
            } else {
                alert("Error Initializing Push Notifications");
                Alloy.Globals.pushToken = null;
            }
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    var __alloyId36 = [];
    $.__views.FeedController = Alloy.createController("Feed", {
        id: "FeedController"
    });
    __alloyId36.push($.__views.FeedController.getViewEx({
        recurse: true
    }));
    $.__views.FriendsController = Alloy.createController("Friends", {
        id: "FriendsController"
    });
    __alloyId36.push($.__views.FriendsController.getViewEx({
        recurse: true
    }));
    $.__views.SettingsController = Alloy.createController("Settings", {
        id: "SettingsController"
    });
    __alloyId36.push($.__views.SettingsController.getViewEx({
        recurse: true
    }));
    $.__views.tabGroup = Ti.UI.createTabGroup({
        tabs: __alloyId36,
        id: "tabGroup"
    });
    $.__views.tabGroup && $.addTopLevelView($.__views.tabGroup);
    doOpen ? $.__views.tabGroup.addEventListener("open", doOpen) : __defers["$.__views.tabGroup!open!doOpen"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.loginSuccessAction = function(_options) {
        initializePushNotifications(_options.model);
        Ti.API.info("logged in user information");
        Ti.API.info(JSON.stringify(_options.model, null, 2));
        $.tabGroup.open();
        $.tabGroup.setActiveTab(0);
        $.feedController.initialize();
        Alloy.Globals.currentUser = _options.model;
        $.feedController.parentController = $;
        $.friendsController.parentController = $;
        $.settingsController.parentController = $;
        $.loginController && $.loginController.close();
    };
    $.userNotLoggedInAction = function() {
        if (!$.loginController) {
            var loginController = Alloy.createController("login", {
                parentController: $,
                reset: true
            });
            $.loginController = loginController;
        }
        $.loginController.open(true);
    };
    $.userLoggedInAction = function() {
        user.showMe(function(_response) {
            if (true === _response.success) $.loginSuccessAction(_response); else {
                alert("Application Error\n " + _response.error.message);
                Ti.API.error(JSON.stringify(_response.error, null, 2));
                $.userNotLoggedInAction();
            }
        });
    };
    var user = Alloy.createModel("User");
    true === user.authenticated() ? $.userLoggedInAction() : $.userNotLoggedInAction();
    Alloy.Globals.openCurrentTabWindow = function(_window) {
        $.tabGroup.activeTab.open(_window);
    };
    __defers["$.__views.tabGroup!open!doOpen"] && $.__views.tabGroup.addEventListener("open", doOpen);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;