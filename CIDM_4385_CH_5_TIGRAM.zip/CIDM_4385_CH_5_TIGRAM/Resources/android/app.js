var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

Alloy.Globals.FB = require("facebook");

Alloy.Globals.PW = require("progressWindow");

Alloy.createController("index");