var activityIndicator, showingIndicator, activityIndicatorWindow, progressTimeout;

var progressIndicator = null;

var androidContainer = null;

exports.showIndicator = function(_messageString, _progressBar) {
    Ti.API.info("showIndicator: " + _messageString);
    androidContainer = Ti.UI.createView({
        top: "200dp",
        width: Ti.UI.FILL,
        height: Ti.UI.SIZE,
        opacity: 1,
        backgroundColor: "black",
        color: "black",
        visible: true
    });
    activityIndicatorWindow = Titanium.UI.createWindow({
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "#58585A",
        opacity: .7,
        fullscreen: true
    });
    activityIndicator = true === _progressBar ? Ti.UI.createProgressBar({
        style: Ti.UI.ActivityIndicatorStyle.DARK,
        top: "10dp",
        bottom: "10dp",
        left: "30dp",
        right: "30dp",
        min: 0,
        max: 1,
        value: 0,
        message: _messageString || "Loading, please wait.",
        color: "white",
        font: {
            fontSize: "20dp",
            fontWeight: "bold"
        },
        opacity: 1,
        backgroundColor: "black"
    }) : Ti.UI.createActivityIndicator({
        style: Ti.UI.ActivityIndicatorStyle.BIG,
        top: "10dp",
        right: "30dp",
        bottom: "10dp",
        left: "30dp",
        message: _messageString || "Loading, please wait.",
        color: "white",
        font: {
            fontSize: "20dp",
            fontWeight: "bold"
        }
    });
    androidContainer.add(activityIndicator);
    activityIndicatorWindow.add(androidContainer);
    activityIndicatorWindow.open();
    activityIndicator.show();
    showingIndicator = true;
    progressTimeout = setTimeout(function() {
        exports.hideIndicator();
    }, 35e3);
};

exports.setProgressValue = function(_value) {
    activityIndicator && activityIndicator.setValue(_value);
};

exports.hideIndicator = function() {
    if (progressTimeout) {
        clearTimeout(progressTimeout);
        progressTimeout = null;
    }
    Ti.API.info("hideIndicator");
    if (!showingIndicator) return;
    activityIndicator.hide();
    androidContainer.remove(activityIndicator);
    activityIndicatorWindow.remove(androidContainer);
    androidContainer = null;
    activityIndicatorWindow.close();
    activityIndicatorWindow = null;
    showingIndicator = false;
    activityIndicator = null;
};